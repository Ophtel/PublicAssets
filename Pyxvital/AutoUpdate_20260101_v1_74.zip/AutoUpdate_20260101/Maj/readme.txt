CCAM V78.0
Vérifié : chaque acte/act/pha n'a pas plus de 4 dont 2 relevés sur la CCAM-SRT PU malgré les 16 grilles
Tarifs au 01/02/2025
Prochains tarifs : aucun


Les tables de tarifs CCAMbis*.TAB contiennent tous les actes ayant une activité 1 ou 4, toutes phases, avec les caractéristiques connues jusqu'à date de référence.