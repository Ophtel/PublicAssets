############################################
# Configuration
############################################

$sesamPath         = "C:\ophtix\sesam"
$updateSourcePath  = Join-Path $sesamPath "AutoUpdate_20260101"
$foldersToUpdate   = @("Test")
$pyxvitaleProcess  = "Pyxvital"   # Without .exe

############################################
# Ensure base directory exists (for logging)
############################################

if (-not (Test-Path $sesamPath)) {
    New-Item -Path $sesamPath -ItemType Directory -Force | Out-Null
}

############################################
# Runtime values
############################################

$timestamp  = Get-Date -Format "yyyyMMdd_HHmmss"
$backupPath = Join-Path $sesamPath "Backup_$timestamp"
$logFile    = Join-Path $sesamPath "update_log_test_$timestamp.txt"

############################################
# Functions
############################################

function Write-Log {
    param ([string]$Message)

    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $entry = "[$ts] $Message"

    Add-Content -Path $logFile -Value $entry
    Write-Host $entry
}

function Test-ProcessRunning {
    param ([string]$ProcessName)
    return @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue).Count -gt 0
}

function Stop-PyxvitaleProcess {
    param ([string]$ProcessName)

    Write-Log "Attempting to stop process: $ProcessName"

    $processes = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue
    if ($processes) {
        $processes | Stop-Process -Force
        Start-Sleep -Seconds 3
        Write-Log "Process '$ProcessName' stopped successfully"
    } else {
        Write-Log "Process '$ProcessName' is not running"
    }
}

############################################
# Script start
############################################

$ErrorActionPreference = "Stop"

try {
    Write-Log "=== Sesam Auto-Update START ==="
    Write-Log "Update source: $updateSourcePath"

    ########################################
    # 1. Stop Pyxvitale BEFORE file changes
    ########################################

    Write-Log "Checking Pyxvitale status..."
    if (Test-ProcessRunning -ProcessName $pyxvitaleProcess) {
        Stop-PyxvitaleProcess -ProcessName $pyxvitaleProcess
    } else {
        Write-Log "Pyxvitale not running"
    }

    ########################################
    # 2. Validate update source
    ########################################

    if (-not (Test-Path $updateSourcePath)) {
        throw "Update source folder not found: $updateSourcePath"
    }

    ########################################
    # 3. Create backup directory
    ########################################

    Write-Log "Creating backup directory: $backupPath"
    New-Item -Path $backupPath -ItemType Directory -Force | Out-Null

    ########################################
    # 4. Backup existing folders
    ########################################

    foreach ($folder in $foldersToUpdate) {
        $sourcePath = Join-Path $sesamPath $folder
        $backupDest = Join-Path $backupPath $folder

        if (Test-Path $sourcePath) {
            Write-Log "Backing up folder: $folder"
            New-Item -Path $backupDest -ItemType Directory -Force | Out-Null
            Copy-Item -Path "$sourcePath\*" -Destination $backupDest -Recurse -Force
        } else {
            Write-Log "Folder $folder does not exist"
        }
    }

    ########################################
    # 5. Copy updated folders
    ########################################

    foreach ($folder in $foldersToUpdate) {
        $updateSource = Join-Path $updateSourcePath $folder
        $destination  = Join-Path $sesamPath $folder

        if (-not (Test-Path $updateSource)) {
            Write-Log "WARNING: Update folder not found: $updateSource"
            continue
        }

        Write-Log "Updating folder: $folder"

        if (-not (Test-Path $destination)) {
            New-Item -Path $destination -ItemType Directory -Force | Out-Null
        }

        Copy-Item -Path "$updateSource\*" -Destination $destination -Recurse -Force
        Write-Log "Folder '$folder' updated successfully"
    }

    ########################################
    # Done
    ########################################

    Write-Log "Update completed successfully"
    Write-Log "Backup location: $backupPath"
    Write-Log "=== Sesam Auto-Update END ==="

    exit 0
}
catch {
    $errorMsg = $_.Exception.Message
    Write-Log "FATAL ERROR: $errorMsg"
    Write-Log $_.ScriptStackTrace
    exit 1
}